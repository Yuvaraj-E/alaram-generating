﻿Public Class Form5

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub wmp1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles wmp1.Enter

    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        wmp1.URL = "C:\Users\ELCOT-Lenovo\Desktop\vb assignment\Alaram generating system\alaramsound.mp3"
    End Sub

    Private Sub wmp1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles wmp1.GotFocus

    End Sub
End Class
