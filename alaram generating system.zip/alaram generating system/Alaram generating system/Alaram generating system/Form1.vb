﻿Public Class Form1
    Public Sub Login_data()
        con.Open()

        Dim dt As New DataTable("tableuser")
        Dim rs As New OleDb.OleDbDataAdapter("select * from tableuser where usernameX = '" & TextBox1.Text & "' and passwordX = '" & TextBox2.Text & "' ", con)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        Label3.Text = dt.Rows.Count
        rs.Dispose()
        con.Close()

        If Val(Label3.Text) = 1 Then
            MsgBox("Succesfully Loged In")
            Me.Hide()
            Form2.Show()
        Else
            MsgBox("Invalid username or password!")
        End If
    End Sub
    Public Sub Display_Data()
        con.Open()

        Dim dt As New DataTable("tableuser")
        Dim rs As New OleDb.OleDbDataAdapter("select * from tableuser", con)
        rs.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
        Label3.Text = dt.Rows.Count
        rs.Dispose()
        con.Close()


    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Login_data()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Display_Data()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        End
    End Sub
End Class
