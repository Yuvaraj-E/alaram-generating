﻿Module Module1
    Public con As New OleDb.OleDbConnection("Provider=Microsoft.JET.OLEDB.4.0;Data Source = dBase.mdb")
End Module
