﻿Public Class Form2

    Private Sub SensorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SensorToolStripMenuItem.Click

    End Sub

    Private Sub InputToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputToolStripMenuItem.Click
        Form3.Show()
    End Sub
End Class